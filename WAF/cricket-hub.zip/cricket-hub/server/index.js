// Load environment variables from project root .env so MONGO_URI can be provided there
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });
const express = require('express');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const MONGO_URI = process.env.MONGO_URI || process.env.MONGOURL || process.env.MONGODB_URI;

if (!MONGO_URI) {
  console.warn('No MONGO_URI found in environment. The server will fail to connect until it is provided.');
}

let dbClient;
let db;

async function connect() {
  if (!dbClient) {
    dbClient = new MongoClient(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    await dbClient.connect();
    db = dbClient.db();
    console.log('Connected to MongoDB');
  }
}

app.get('/api/players', async (req, res) => {
  try {
    await connect();
    const players = await db.collection('players').find().toArray();
    res.json(players);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch players' });
  }
});

app.get('/api/players/:id', async (req, res) => {
  try {
    await connect();
    const id = req.params.id;
    const player = await db.collection('players').findOne({ _id: new ObjectId(id) });
    if (!player) return res.status(404).json({ error: 'Player not found' });
    res.json(player);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch player' });
  }
});

app.get('/api/matches', async (req, res) => {
  try {
    await connect();
    const matches = await db.collection('matches').find().toArray();
    res.json(matches);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch matches' });
  }
});

// Admin endpoint to trigger seed/update for 2025 data (POST)
app.post('/api/seed/2025', async (req, res) => {
  try {
    await connect();
    const seed = require('./seed2025');
    const result = await seed(db);
    res.json({ ok: true, result });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to seed 2025 data' });
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});

process.on('SIGINT', async () => {
  if (dbClient) await dbClient.close();
  process.exit(0);
});
