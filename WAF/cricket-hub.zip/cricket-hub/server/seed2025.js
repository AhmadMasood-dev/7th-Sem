// seed2025.js
// Connects to the db passed in and inserts/updates sample 2025 data.
// Load environment variables when run directly
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });

async function seed2025(db) {
  // Example 2025 data. Replace or extend with real updated 2025 records.
  const players2025 = [
    {
      name: 'Virat Kohli',
      country: 'India',
      role: 'Batter',
      stats: { matches: 110, runs: 4200, year: 2025 }
    },
    {
      name: 'Joe Root',
      country: 'England',
      role: 'Batter',
      stats: { matches: 90, runs: 3200, year: 2025 }
    }
  ];

  const matches2025 = [
    {
      date: '2025-03-12',
      teams: ['India', 'Australia'],
      venue: 'Wankhede Stadium',
      result: 'India won by 6 wickets',
      year: 2025
    },
    {
      date: '2025-05-04',
      teams: ['England', 'Pakistan'],
      venue: 'Lord\'s',
      result: 'Match drawn',
      year: 2025
    }
  ];

  // Upsert players by name
  const playerOps = players2025.map(p => ({
    updateOne: {
      filter: { name: p.name },
      update: { $set: p },
      upsert: true
    }
  }));

  const matchOps = matches2025.map((m, idx) => ({
    updateOne: {
      filter: { date: m.date, venue: m.venue },
      update: { $set: m },
      upsert: true
    }
  }));

  const playerResult = await db.collection('players').bulkWrite(playerOps);
  const matchResult = await db.collection('matches').bulkWrite(matchOps);

  return { playerResult, matchResult };
}

module.exports = seed2025;

// If run directly, connect to MongoDB using env and execute the seed
if (require.main === module) {
  (async () => {
    const { MongoClient } = require('mongodb');
    const MONGO_URI = process.env.MONGO_URI || process.env.MONGOURL || process.env.MONGODB_URI;
    if (!MONGO_URI) {
      console.error('MONGO_URI missing in environment');
      process.exit(1);
    }
    const client = new MongoClient(MONGO_URI);
    try {
      await client.connect();
      const db = client.db();
      const result = await seed2025(db);
      console.log('Seed result:', result);
    } catch (err) {
      console.error(err);
      process.exit(1);
    } finally {
      await client.close();
    }
  })();
}
