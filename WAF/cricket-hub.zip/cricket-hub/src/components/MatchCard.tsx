import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface MatchCardProps {
  team1: string;
  team2: string;
  team1Score: string;
  team2Score: string;
  status: string;
  venue: string;
  date: string;
  result?: string;
}

const MatchCard = ({
  team1,
  team2,
  team1Score,
  team2Score,
  status,
  venue,
  date,
  result,
}: MatchCardProps) => {
  return (
    <Card className="p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <Badge variant={status === "Live" ? "destructive" : "secondary"}>
          {status}
        </Badge>
        <span className="text-sm text-muted-foreground">{date}</span>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="font-bold text-primary">{team1.substring(0, 3).toUpperCase()}</span>
            </div>
            <span className="font-semibold text-lg">{team1}</span>
          </div>
          <span className="font-bold text-xl">{team1Score}</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
              <span className="font-bold text-accent">{team2.substring(0, 3).toUpperCase()}</span>
            </div>
            <span className="font-semibold text-lg">{team2}</span>
          </div>
          <span className="font-bold text-xl">{team2Score}</span>
        </div>
      </div>

      {result && (
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-sm font-medium text-primary">{result}</p>
        </div>
      )}

      <div className="mt-4">
        <p className="text-sm text-muted-foreground">{venue}</p>
      </div>
    </Card>
  );
};

export default MatchCard;
