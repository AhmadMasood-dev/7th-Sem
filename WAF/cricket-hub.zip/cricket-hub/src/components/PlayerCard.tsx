import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { useNavigate } from "react-router-dom";

interface PlayerCardProps {
  id: string;
  name: string;
  role: string;
  team: string;
  matches?: number;
  runs?: number;
  wickets?: number;
}

const PlayerCard = ({ id, name, role, team, matches, runs, wickets }: PlayerCardProps) => {
  const navigate = useNavigate();

  return (
    <Card
      className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-105"
      onClick={() => navigate(`/player/${id}`)}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
          <span className="text-2xl font-bold text-white">
            {name.split(" ").map(n => n[0]).join("").substring(0, 2)}
          </span>
        </div>
        <Badge variant="secondary">{role}</Badge>
      </div>

      <h3 className="font-bold text-xl mb-1">{name}</h3>
      <p className="text-muted-foreground mb-4">{team}</p>

      {(matches !== undefined || runs !== undefined || wickets !== undefined) && (
        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
          {matches !== undefined && (
            <div>
              <p className="text-sm text-muted-foreground">Matches</p>
              <p className="font-bold text-lg">{matches}</p>
            </div>
          )}
          {runs !== undefined && (
            <div>
              <p className="text-sm text-muted-foreground">Runs</p>
              <p className="font-bold text-lg">{runs}</p>
            </div>
          )}
          {wickets !== undefined && (
            <div>
              <p className="text-sm text-muted-foreground">Wickets</p>
              <p className="font-bold text-lg">{wickets}</p>
            </div>
          )}
        </div>
      )}
    </Card>
  );
};

export default PlayerCard;
