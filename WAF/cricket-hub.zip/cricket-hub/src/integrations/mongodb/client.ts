/* Frontend integration that talks to the local Express API which uses MongoDB.
   Use like: import { fetchPlayers } from '@/integrations/mongodb/client'
*/

const API_URL =  'http://localhost:4000';

export async function fetchPlayers() {
  const res = await fetch(`${API_URL}/api/players`);
  if (!res.ok) throw new Error('Failed to fetch players');
  return res.json();
}

export async function fetchPlayerById(id: string) {
  const res = await fetch(`${API_URL}/api/players/${encodeURIComponent(id)}`);
  if (!res.ok) throw new Error('Failed to fetch player');
  return res.json();
}

export async function fetchMatches() {
  const res = await fetch(`${API_URL}/api/matches`);
  if (!res.ok) throw new Error('Failed to fetch matches');
  return res.json();
}

// Admin call to trigger seed/update for 2025
export async function triggerSeed2025() {
  const res = await fetch(`${API_URL}/api/seed/2025`, { method: 'POST' });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Failed to seed 2025: ${body}`);
  }
  return res.json();
}
