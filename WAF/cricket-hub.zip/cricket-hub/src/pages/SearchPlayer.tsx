import Navigation from "@/components/Navigation";
import PlayerCard from "@/components/PlayerCard";
import { useSearchParams } from "react-router-dom";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";

const SearchPlayer = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "");
  const [filteredPlayers, setFilteredPlayers] = useState<any[]>([]);

  // Combined player data
  const allPlayers = [
    { id: "rohit-sharma", name: "Rohit Sharma", role: "Batsman (C)", team: "India", matches: 45, runs: 3500, wickets: 0 },
    { id: "virat-kohli", name: "Virat Kohli", role: "Batsman", team: "India", matches: 98, runs: 4000, wickets: 0 },
    { id: "kl-rahul", name: "KL Rahul", role: "Wicket-keeper", team: "India", matches: 55, runs: 2000, wickets: 0 },
    { id: "hardik-pandya", name: "Hardik Pandya", role: "All-rounder", team: "India", matches: 70, runs: 1500, wickets: 45 },
    { id: "ravindra-jadeja", name: "Ravindra Jadeja", role: "All-rounder", team: "India", matches: 60, runs: 900, wickets: 50 },
    { id: "jasprit-bumrah", name: "Jasprit Bumrah", role: "Bowler", team: "India", matches: 65, runs: 50, wickets: 90 },
    { id: "aaron-finch", name: "Aaron Finch", role: "Batsman (C)", team: "Australia", matches: 95, runs: 2700, wickets: 0 },
    { id: "david-warner", name: "David Warner", role: "Batsman", team: "Australia", matches: 90, runs: 2500, wickets: 0 },
    { id: "steve-smith", name: "Steve Smith", role: "Batsman", team: "Australia", matches: 50, runs: 1800, wickets: 0 },
    { id: "glenn-maxwell", name: "Glenn Maxwell", role: "All-rounder", team: "Australia", matches: 100, runs: 2100, wickets: 60 },
    { id: "pat-cummins", name: "Pat Cummins", role: "Bowler", team: "Australia", matches: 40, runs: 200, wickets: 55 },
    { id: "mitchell-starc", name: "Mitchell Starc", role: "Bowler", team: "Australia", matches: 50, runs: 150, wickets: 70 },
  ];

  useEffect(() => {
    const query = searchParams.get("q") || "";
    setSearchQuery(query);
    
    if (query.trim()) {
      const results = allPlayers.filter((player) =>
        player.name.toLowerCase().includes(query.toLowerCase()) ||
        player.team.toLowerCase().includes(query.toLowerCase()) ||
        player.role.toLowerCase().includes(query.toLowerCase())
      );
      setFilteredPlayers(results);
    } else {
      setFilteredPlayers(allPlayers);
    }
  }, [searchParams]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery.trim() });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto mb-12">
          <h1 className="text-4xl font-bold mb-4 text-center">Search Players</h1>
          <p className="text-muted-foreground text-center mb-8">
            Find cricket players by name, team, or role
          </p>
          
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for players..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-14 text-lg"
              />
            </div>
          </form>
        </div>

        {searchQuery && (
          <div className="mb-6">
            <p className="text-muted-foreground">
              Found <span className="font-bold text-foreground">{filteredPlayers.length}</span> results
              {searchQuery && ` for "${searchQuery}"`}
            </p>
          </div>
        )}

        {filteredPlayers.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredPlayers.map((player) => (
              <PlayerCard key={player.id} {...player} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-2xl font-bold mb-2">No players found</h3>
            <p className="text-muted-foreground">
              Try searching with a different name, team, or role
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchPlayer;
