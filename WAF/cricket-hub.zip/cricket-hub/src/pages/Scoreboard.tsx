import Navigation from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const Scoreboard = () => {
  // Mock detailed match data
  const liveMatch = {
    team1: "England",
    team2: "South Africa",
    team1Score: "145/8",
    team2Score: "142/6",
    team1Overs: "18.2",
    team2Overs: "20",
    status: "Live",
    venue: "Lord's Cricket Ground",
    date: "Nov 18, 2024",
    target: "146 runs",
  };

  const team1Batsmen = [
    { name: "J. Bairstow", runs: 45, balls: 32, fours: 6, sixes: 1, sr: "140.62" },
    { name: "J. Root", runs: 38, balls: 28, fours: 4, sixes: 2, sr: "135.71" },
    { name: "B. Stokes", runs: 22, balls: 18, fours: 3, sixes: 0, sr: "122.22" },
    { name: "J. Buttler*", runs: 15, balls: 12, fours: 2, sixes: 0, sr: "125.00" },
    { name: "M. Ali", runs: 8, balls: 6, fours: 1, sixes: 0, sr: "133.33" },
  ];

  const team1Bowlers = [
    { name: "K. Rabada", overs: "4", runs: 32, wickets: 2, economy: "8.00" },
    { name: "L. Ngidi", overs: "3.2", runs: 28, wickets: 3, economy: "8.40" },
    { name: "A. Nortje", overs: "4", runs: 35, wickets: 1, economy: "8.75" },
    { name: "T. Shamsi", overs: "4", runs: 28, wickets: 2, economy: "7.00" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Live Scoreboard</h1>
          <p className="text-muted-foreground">Real-time match updates and detailed statistics</p>
        </div>

        {/* Match Header */}
        <Card className="p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <Badge variant="destructive" className="text-lg px-4 py-1">
              {liveMatch.status}
            </Badge>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">{liveMatch.venue}</p>
              <p className="text-sm text-muted-foreground">{liveMatch.date}</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-border pb-4">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-bold text-primary text-lg">
                    {liveMatch.team1.substring(0, 3).toUpperCase()}
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-xl">{liveMatch.team1}</h3>
                  <p className="text-sm text-muted-foreground">Batting</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold">{liveMatch.team1Score}</p>
                <p className="text-muted-foreground">({liveMatch.team1Overs} ov)</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                  <span className="font-bold text-accent text-lg">
                    {liveMatch.team2.substring(0, 3).toUpperCase()}
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-xl">{liveMatch.team2}</h3>
                  <p className="text-sm text-muted-foreground">Bowling</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold">{liveMatch.team2Score}</p>
                <p className="text-muted-foreground">({liveMatch.team2Overs} ov)</p>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-primary/5 rounded-lg">
            <p className="font-medium text-center">
              England need <span className="text-primary font-bold">4 runs</span> from 10 balls
            </p>
          </div>
        </Card>

        {/* Detailed Stats */}
        <Card className="p-6">
          <Tabs defaultValue="batting">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="batting">Batting</TabsTrigger>
              <TabsTrigger value="bowling">Bowling</TabsTrigger>
            </TabsList>

            <TabsContent value="batting">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 font-semibold">Batsman</th>
                      <th className="text-center py-3 font-semibold">R</th>
                      <th className="text-center py-3 font-semibold">B</th>
                      <th className="text-center py-3 font-semibold">4s</th>
                      <th className="text-center py-3 font-semibold">6s</th>
                      <th className="text-center py-3 font-semibold">SR</th>
                    </tr>
                  </thead>
                  <tbody>
                    {team1Batsmen.map((batsman, index) => (
                      <tr key={index} className="border-b border-border/50">
                        <td className="py-3 font-medium">{batsman.name}</td>
                        <td className="text-center py-3">{batsman.runs}</td>
                        <td className="text-center py-3">{batsman.balls}</td>
                        <td className="text-center py-3">{batsman.fours}</td>
                        <td className="text-center py-3">{batsman.sixes}</td>
                        <td className="text-center py-3">{batsman.sr}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="bowling">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 font-semibold">Bowler</th>
                      <th className="text-center py-3 font-semibold">O</th>
                      <th className="text-center py-3 font-semibold">R</th>
                      <th className="text-center py-3 font-semibold">W</th>
                      <th className="text-center py-3 font-semibold">Econ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {team1Bowlers.map((bowler, index) => (
                      <tr key={index} className="border-b border-border/50">
                        <td className="py-3 font-medium">{bowler.name}</td>
                        <td className="text-center py-3">{bowler.overs}</td>
                        <td className="text-center py-3">{bowler.runs}</td>
                        <td className="text-center py-3">{bowler.wickets}</td>
                        <td className="text-center py-3">{bowler.economy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
};

export default Scoreboard;
