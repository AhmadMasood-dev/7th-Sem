import Navigation from "@/components/Navigation";
import MatchCard from "@/components/MatchCard";
import { Trophy, TrendingUp, Users, Calendar, Star, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const Index = () => {
  // Mock data - will be replaced with API data
  const liveMatches = [
    {
      team1: "England",
      team2: "South Africa",
      team1Score: "145/8 (18.2)",
      team2Score: "142/6 (20)",
      status: "Live",
      venue: "Lord's Cricket Ground",
      date: "Nov 18, 2024",
      result: "",
    },
  ];

  const recentMatches = [
    {
      team1: "India",
      team2: "Australia",
      team1Score: "185/7 (20)",
      team2Score: "177/9 (20)",
      status: "Completed",
      venue: "Melbourne Cricket Ground",
      date: "Nov 15, 2024",
      result: "India won by 8 runs",
    },
    {
      team1: "Pakistan",
      team2: "New Zealand",
      team1Score: "201/5 (20)",
      team2Score: "195/8 (20)",
      status: "Completed",
      venue: "National Stadium Karachi",
      date: "Nov 17, 2024",
      result: "Pakistan won by 6 runs",
    },
    {
      team1: "West Indies",
      team2: "Bangladesh",
      team1Score: "168/9 (20)",
      team2Score: "171/4 (19.1)",
      status: "Completed",
      venue: "Kensington Oval",
      date: "Nov 14, 2024",
      result: "Bangladesh won by 6 wickets",
    },
  ];

  const upcomingMatches = [
    {
      team1: "Sri Lanka",
      team2: "Afghanistan",
      venue: "R. Premadasa Stadium",
      date: "Nov 20, 2024",
      time: "7:00 PM IST",
    },
    {
      team1: "Australia",
      team2: "Pakistan",
      venue: "Sydney Cricket Ground",
      date: "Nov 21, 2024",
      time: "2:00 PM AEDT",
    },
    {
      team1: "India",
      team2: "England",
      venue: "Wankhede Stadium",
      date: "Nov 22, 2024",
      time: "7:00 PM IST",
    },
  ];

  const topPerformers = [
    {
      name: "Virat Kohli",
      team: "India",
      stat: "512 runs",
      matches: "12",
      average: "51.2",
    },
    {
      name: "Mitchell Starc",
      team: "Australia",
      stat: "18 wickets",
      matches: "10",
      average: "18.5",
    },
    {
      name: "Jos Buttler",
      team: "England",
      stat: "428 runs",
      matches: "11",
      average: "42.8",
    },
    {
      name: "Rashid Khan",
      team: "Afghanistan",
      stat: "16 wickets",
      matches: "9",
      average: "15.2",
    },
  ];

  const highlights = [
    {
      title: "India's Spectacular Victory",
      description: "India clinches thriller against Australia in Melbourne with brilliant death bowling",
      date: "Nov 15, 2024",
    },
    {
      title: "Pakistan's Bowling Masterclass",
      description: "Pakistan's pace attack dismantles New Zealand batting lineup in Karachi",
      date: "Nov 17, 2024",
    },
    {
      title: "Bangladesh's Historic Win",
      description: "Bangladesh chases down 169 with ease, marking their best performance of the season",
      date: "Nov 14, 2024",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative py-24 px-4 bg-gradient-to-br from-cricket-green/20 via-background to-team-blue/10 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/placeholder.svg')] opacity-5"></div>
        <div className="container mx-auto relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
              2024-2025 Season Live Now
            </Badge>
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-primary to-cricket-green-dark mb-6 shadow-lg">
              <Trophy className="w-12 h-12 text-primary-foreground" />
            </div>
            <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cricket-green via-primary to-team-blue bg-clip-text text-transparent">
              Cricket Hub Central
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Experience the thrill of cricket with live scores, comprehensive statistics, player profiles, and real-time match updates from the 2024-2025 season
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button size="lg" className="gap-2">
                <span>View Live Matches</span>
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline" className="gap-2">
                <Calendar className="w-4 h-4" />
                <span>Match Schedule</span>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Live Matches */}
      {liveMatches.length > 0 && (
        <section className="py-8 px-4 bg-destructive/5 border-y border-destructive/20">
          <div className="container mx-auto">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-3 h-3 rounded-full bg-destructive animate-pulse"></div>
              <h2 className="text-2xl font-bold">Live Now</h2>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {liveMatches.map((match, index) => (
                <MatchCard key={index} {...match} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Recent Matches */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Recent Matches</h2>
              <p className="text-muted-foreground">Latest results from the 2024-2025 season</p>
            </div>
            <Button variant="ghost" className="gap-2">
              <span>View All</span>
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentMatches.map((match, index) => (
              <MatchCard key={index} {...match} />
            ))}
          </div>
        </div>
      </section>

      {/* Top Performers */}
      <section className="py-12 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <Star className="w-8 h-8 text-primary" />
            <div>
              <h2 className="text-3xl font-bold">Top Performers</h2>
              <p className="text-muted-foreground">Leading players of the season</p>
            </div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {topPerformers.map((player, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-cricket-green-dark flex items-center justify-center text-primary-foreground font-bold text-lg">
                      {player.name.charAt(0)}
                    </div>
                    <Badge variant="secondary">{player.team}</Badge>
                  </div>
                  <h3 className="font-bold text-lg mb-2">{player.name}</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Performance</span>
                      <span className="font-semibold text-primary">{player.stat}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Matches</span>
                      <span className="font-semibold">{player.matches}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Average</span>
                      <span className="font-semibold">{player.average}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Upcoming Matches */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <Calendar className="w-8 h-8 text-accent" />
            <div>
              <h2 className="text-3xl font-bold">Upcoming Matches</h2>
              <p className="text-muted-foreground">Don't miss these exciting fixtures</p>
            </div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingMatches.map((match, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <Badge className="mb-4 bg-accent/10 text-accent border-accent/20">
                    Upcoming
                  </Badge>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="font-bold text-primary text-sm">
                            {match.team1.substring(0, 3).toUpperCase()}
                          </span>
                        </div>
                        <span className="font-semibold">{match.team1}</span>
                      </div>
                    </div>
                    <div className="text-center text-muted-foreground font-medium">vs</div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                          <span className="font-bold text-accent text-sm">
                            {match.team2.substring(0, 3).toUpperCase()}
                          </span>
                        </div>
                        <span className="font-semibold">{match.team2}</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-border space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Date</span>
                      <span className="font-medium">{match.date}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Time</span>
                      <span className="font-medium">{match.time}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">{match.venue}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Highlights */}
      <section className="py-12 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <TrendingUp className="w-8 h-8 text-primary" />
            <div>
              <h2 className="text-3xl font-bold">Latest Highlights</h2>
              <p className="text-muted-foreground">Top stories from recent matches</p>
            </div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {highlights.map((highlight, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer group">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <Badge variant="outline">{highlight.date}</Badge>
                  </div>
                  <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">
                    {highlight.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {highlight.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Season Statistics */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <Users className="w-8 h-8 text-primary" />
            <div>
              <h2 className="text-3xl font-bold">2024-2025 Season Statistics</h2>
              <p className="text-muted-foreground">Key numbers from the current season</p>
            </div>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow border-primary/20">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Trophy className="w-6 h-6 text-primary" />
              </div>
              <p className="text-4xl font-bold text-primary mb-2">187</p>
              <p className="text-muted-foreground font-medium">Total Matches</p>
              <p className="text-xs text-muted-foreground mt-1">Across all formats</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow border-accent/20">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-accent/10 flex items-center justify-center">
                <Calendar className="w-6 h-6 text-accent" />
              </div>
              <p className="text-4xl font-bold text-accent mb-2">28</p>
              <p className="text-muted-foreground font-medium">Active Series</p>
              <p className="text-xs text-muted-foreground mt-1">International tournaments</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow border-cricket-green/20">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-cricket-green/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-cricket-green" />
              </div>
              <p className="text-4xl font-bold text-cricket-green mb-2">642</p>
              <p className="text-muted-foreground font-medium">Players</p>
              <p className="text-xs text-muted-foreground mt-1">Active in season</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow border-team-blue/20">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-team-blue/10 flex items-center justify-center">
                <Star className="w-6 h-6 text-team-blue" />
              </div>
              <p className="text-4xl font-bold text-team-blue mb-2">15</p>
              <p className="text-muted-foreground font-medium">Countries</p>
              <p className="text-xs text-muted-foreground mt-1">Participating nations</p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
