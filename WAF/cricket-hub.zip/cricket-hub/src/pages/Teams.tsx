import Navigation from "@/components/Navigation";
import PlayerCard from "@/components/PlayerCard";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const Teams = () => {
  // T20 World Cup Final Teams Data
  const indiaPlayers = [
    { id: "rohit-sharma", name: "Rohit Sharma", role: "Batsman (C)", team: "India", matches: 45, runs: 3500, wickets: 0 },
    { id: "virat-kohli", name: "Virat Kohli", role: "Batsman", team: "India", matches: 98, runs: 4000, wickets: 0 },
    { id: "kl-rahul", name: "KL Rahul", role: "Wicket-keeper", team: "India", matches: 55, runs: 2000, wickets: 0 },
    { id: "hardik-pandya", name: "Hardik Pandya", role: "All-rounder", team: "India", matches: 70, runs: 1500, wickets: 45 },
    { id: "ravindra-jadeja", name: "Ravindra Jadeja", role: "All-rounder", team: "India", matches: 60, runs: 900, wickets: 50 },
    { id: "jasprit-bumrah", name: "Jasprit Bumrah", role: "Bowler", team: "India", matches: 65, runs: 50, wickets: 90 },
    { id: "mohammed-shami", name: "Mohammed Shami", role: "Bowler", team: "India", matches: 55, runs: 100, wickets: 80 },
    { id: "yuzvendra-chahal", name: "Yuzvendra Chahal", role: "Bowler", team: "India", matches: 60, runs: 80, wickets: 95 },
  ];

  const australiaPlayers = [
    { id: "aaron-finch", name: "Aaron Finch", role: "Batsman (C)", team: "Australia", matches: 95, runs: 2700, wickets: 0 },
    { id: "david-warner", name: "David Warner", role: "Batsman", team: "Australia", matches: 90, runs: 2500, wickets: 0 },
    { id: "steve-smith", name: "Steve Smith", role: "Batsman", team: "Australia", matches: 50, runs: 1800, wickets: 0 },
    { id: "glenn-maxwell", name: "Glenn Maxwell", role: "All-rounder", team: "Australia", matches: 100, runs: 2100, wickets: 60 },
    { id: "marcus-stoinis", name: "Marcus Stoinis", role: "All-rounder", team: "Australia", matches: 45, runs: 900, wickets: 35 },
    { id: "pat-cummins", name: "Pat Cummins", role: "Bowler", team: "Australia", matches: 40, runs: 200, wickets: 55 },
    { id: "mitchell-starc", name: "Mitchell Starc", role: "Bowler", team: "Australia", matches: 50, runs: 150, wickets: 70 },
    { id: "adam-zampa", name: "Adam Zampa", role: "Bowler", team: "Australia", matches: 65, runs: 50, wickets: 85 },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">ICC Men's T20 World Cup Final Teams</h1>
          <p className="text-muted-foreground">
            Explore the squads from the T20 World Cup final between India and Australia
          </p>
        </div>

        <Tabs defaultValue="india" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="india" className="text-lg">
              🇮🇳 India
            </TabsTrigger>
            <TabsTrigger value="australia" className="text-lg">
              🇦🇺 Australia
            </TabsTrigger>
          </TabsList>

          <TabsContent value="india">
            <Card className="p-6 mb-6 bg-gradient-to-br from-blue-500/10 to-orange-500/10">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold mb-2">Team India</h2>
                  <p className="text-muted-foreground">Captain: Rohit Sharma</p>
                </div>
                <div className="text-6xl">🇮🇳</div>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary">{indiaPlayers.length}</p>
                  <p className="text-sm text-muted-foreground">Players</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary">4</p>
                  <p className="text-sm text-muted-foreground">Bowlers</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-primary">3</p>
                  <p className="text-sm text-muted-foreground">All-rounders</p>
                </div>
              </div>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {indiaPlayers.map((player) => (
                <PlayerCard key={player.id} {...player} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="australia">
            <Card className="p-6 mb-6 bg-gradient-to-br from-yellow-500/10 to-green-500/10">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold mb-2">Team Australia</h2>
                  <p className="text-muted-foreground">Captain: Aaron Finch</p>
                </div>
                <div className="text-6xl">🇦🇺</div>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-6">
                <div className="text-center">
                  <p className="text-3xl font-bold text-accent">{australiaPlayers.length}</p>
                  <p className="text-sm text-muted-foreground">Players</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-accent">4</p>
                  <p className="text-sm text-muted-foreground">Bowlers</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-accent">2</p>
                  <p className="text-sm text-muted-foreground">All-rounders</p>
                </div>
              </div>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {australiaPlayers.map((player) => (
                <PlayerCard key={player.id} {...player} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Teams;
