import Navigation from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, TrendingUp, Award } from "lucide-react";
import { Button } from "@/components/ui/button";

const PlayerDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock player data - will be replaced with API data
  const playerData: Record<string, any> = {
    "rohit-sharma": {
      name: "Rohit Sharma",
      role: "Batsman",
      team: "India",
      captain: true,
      age: 36,
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm off break",
      matches: 45,
      runs: 3500,
      average: "45.50",
      strikeRate: "140.20",
      highestScore: "118",
      centuries: 4,
      fifties: 28,
      wickets: 0,
    },
    "virat-kohli": {
      name: "Virat Kohli",
      role: "Batsman",
      team: "India",
      captain: false,
      age: 35,
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium",
      matches: 98,
      runs: 4000,
      average: "52.70",
      strikeRate: "137.50",
      highestScore: "122*",
      centuries: 5,
      fifties: 35,
      wickets: 4,
    },
  };

  const player = playerData[id || ""] || playerData["rohit-sharma"];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          className="mb-6"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        {/* Player Header */}
        <Card className="p-8 mb-6 bg-gradient-to-br from-primary/10 to-accent/10">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <span className="text-5xl font-bold text-white">
                {player.name.split(" ").map((n: string) => n[0]).join("")}
              </span>
            </div>
            
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-4xl font-bold">{player.name}</h1>
                {player.captain && (
                  <Badge variant="default" className="text-base">
                    Captain
                  </Badge>
                )}
              </div>
              <div className="flex flex-wrap gap-4 text-muted-foreground mb-4">
                <p>{player.role} • {player.team}</p>
                <p>Age: {player.age}</p>
              </div>
              <div className="flex flex-wrap gap-3">
                <Badge variant="secondary">{player.battingStyle}</Badge>
                <Badge variant="secondary">{player.bowlingStyle}</Badge>
              </div>
            </div>
          </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Career Stats */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h2 className="text-2xl font-bold">Career Statistics</h2>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Matches</p>
                <p className="text-3xl font-bold">{player.matches}</p>
              </div>
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Runs</p>
                <p className="text-3xl font-bold text-primary">{player.runs}</p>
              </div>
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Average</p>
                <p className="text-3xl font-bold">{player.average}</p>
              </div>
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Strike Rate</p>
                <p className="text-3xl font-bold">{player.strikeRate}</p>
              </div>
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Highest Score</p>
                <p className="text-3xl font-bold text-accent">{player.highestScore}</p>
              </div>
              <div className="p-4 bg-muted/30 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Wickets</p>
                <p className="text-3xl font-bold">{player.wickets}</p>
              </div>
            </div>
          </Card>

          {/* Achievements */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Award className="w-5 h-5 text-primary" />
              <h2 className="text-2xl font-bold">Achievements</h2>
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <span className="font-medium">Centuries</span>
                <span className="text-2xl font-bold text-primary">{player.centuries}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <span className="font-medium">Half Centuries</span>
                <span className="text-2xl font-bold text-accent">{player.fifties}</span>
              </div>
              <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                <p className="text-sm font-medium text-primary mb-1">🏆 Notable Achievement</p>
                <p className="text-sm text-muted-foreground">
                  ICC T20I Team of the Year (2023)
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Recent Form */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold mb-4">Recent Form</h2>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {[45, 22, 89, 0, 67, 34, 103, 56, 12, 78].map((score, index) => (
              <div
                key={index}
                className={`flex-shrink-0 w-16 h-16 rounded-lg flex items-center justify-center font-bold ${
                  score >= 50
                    ? "bg-primary/20 text-primary"
                    : score === 0
                    ? "bg-destructive/20 text-destructive"
                    : "bg-muted"
                }`}
              >
                {score}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default PlayerDetail;
