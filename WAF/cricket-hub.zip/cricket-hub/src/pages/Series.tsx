import Navigation from "@/components/Navigation";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, MapPin } from "lucide-react";

const Series = () => {
  const seriesList = [
    {
      name: "ICC Men's T20 World Cup 2024",
      format: "T20",
      status: "Ongoing",
      startDate: "Oct 15, 2024",
      endDate: "Nov 30, 2024",
      location: "Australia",
      teams: 16,
      matches: 45,
    },
    {
      name: "Border-Gavaskar Trophy 2024",
      format: "Test",
      status: "Upcoming",
      startDate: "Dec 1, 2024",
      endDate: "Jan 15, 2025",
      location: "India",
      teams: 2,
      matches: 5,
    },
    {
      name: "England vs South Africa ODI Series",
      format: "ODI",
      status: "Ongoing",
      startDate: "Nov 10, 2024",
      endDate: "Nov 25, 2024",
      location: "England",
      teams: 2,
      matches: 3,
    },
    {
      name: "Pakistan vs New Zealand Test Series",
      format: "Test",
      status: "Completed",
      startDate: "Oct 1, 2024",
      endDate: "Oct 28, 2024",
      location: "Pakistan",
      teams: 2,
      matches: 3,
    },
    {
      name: "Asia Cup 2024",
      format: "ODI",
      status: "Upcoming",
      startDate: "Feb 1, 2025",
      endDate: "Feb 20, 2025",
      location: "Sri Lanka",
      teams: 6,
      matches: 15,
    },
    {
      name: "Women's T20 World Cup 2024",
      format: "T20",
      status: "Ongoing",
      startDate: "Nov 1, 2024",
      endDate: "Nov 24, 2024",
      location: "South Africa",
      teams: 10,
      matches: 30,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Ongoing":
        return "destructive";
      case "Upcoming":
        return "secondary";
      case "Completed":
        return "outline";
      default:
        return "secondary";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Cricket Series</h1>
          <p className="text-muted-foreground">
            Explore ongoing and upcoming international cricket series
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {seriesList.map((series, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <Badge variant={getStatusColor(series.status)}>{series.status}</Badge>
                <Badge variant="outline">{series.format}</Badge>
              </div>

              <h3 className="font-bold text-xl mb-4">{series.name}</h3>

              <div className="space-y-3 mb-4">
                <div className="flex items-start text-sm">
                  <CalendarDays className="w-4 h-4 mr-2 mt-0.5 text-muted-foreground" />
                  <div>
                    <p className="text-muted-foreground">
                      {series.startDate} - {series.endDate}
                    </p>
                  </div>
                </div>

                <div className="flex items-center text-sm">
                  <MapPin className="w-4 h-4 mr-2 text-muted-foreground" />
                  <p className="text-muted-foreground">{series.location}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                <div>
                  <p className="text-sm text-muted-foreground">Teams</p>
                  <p className="font-bold text-lg">{series.teams}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Matches</p>
                  <p className="font-bold text-lg">{series.matches}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Series;
