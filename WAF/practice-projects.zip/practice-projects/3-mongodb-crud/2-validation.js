// ============================================
// WEEK 7: Schema Validation
// ============================================

const mongoose = require("mongoose");

// ============================================
// SCHEMA WITH VALIDATIONS
// ============================================

const userSchema = new mongoose.Schema({
  // BUILT-IN VALIDATION
  name: {
    type: String,
    required: [true, "Name is required"],
    minlength: [3, "Name must be at least 3 characters"],
    maxlength: [50, "Name cannot exceed 50 characters"],
    trim: true
  },

  email: {
    type: String,
    required: true,
    unique: [true, "Email already exists"],
    lowercase: true,
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      "Invalid email format"
    ]
  },

  age: {
    type: Number,
    min: [18, "Age must be at least 18"],
    max: [120, "Age cannot exceed 120"]
  },

  phone: {
    type: String,
    match: [/^\d{10}$/, "Phone must be 10 digits"]
  },

  country: {
    type: String,
    enum: ["Pakistan", "India", "USA", "UK", "Canada"],
    default: "Pakistan"
  },

  createdAt: {
    type: Date,
    default: Date.now
  }
});

// ============================================
// CUSTOM VALIDATION
// ============================================

userSchema.pre("save", async function(next) {
  // Custom validation before saving
  if (this.age && this.age < 18) {
    throw new Error("User must be 18 or older");
  }

  console.log(`✓ Pre-save validation passed for ${this.name}`);
  next();
});

userSchema.post("save", function() {
  console.log(`✓ User saved: ${this.name}`);
});

// ============================================
// ASYNC VALIDATION
// ============================================

userSchema.path("email").validate(async function(email) {
  const user = await mongoose.model("User").findOne({ email });
  return !user;
}, "Email already registered");

// ============================================
// EXAMPLE USAGE
// ============================================

/*
const User = mongoose.model("User", userSchema);

// Valid user
const validUser = new User({
  name: "Alice",
  email: "alice@example.com",
  age: 25,
  phone: "0300123456",
  country: "Pakistan"
});

try {
  await validUser.save();
  console.log("✓ Valid user saved");
} catch (error) {
  console.error("❌ Validation error:", error.message);
}

// Invalid user (age too young)
const invalidUser = new User({
  name: "Bob",
  email: "bob@example.com",
  age: 15
});

try {
  await invalidUser.save();
} catch (error) {
  console.error("❌ Validation error:", error.message);
  // Output: "User must be 18 or older"
}
*/

module.exports = userSchema;
