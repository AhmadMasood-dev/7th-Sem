// ============================================
// WEEK 7-8: MongoDB with Mongoose
// ============================================

const express = require("express");
const mongoose = require("mongoose");
const app = express();
const PORT = 3004;

console.log("=== MONGODB + MONGOOSE ===\n");

// Middleware
app.use(express.json());

// ============================================
// DATABASE CONNECTION
// ============================================

// Connect to MongoDB (local)
mongoose.connect("mongodb://localhost:27017/student-db", {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✓ Connected to MongoDB"))
.catch(err => console.error("MongoDB error:", err));

// ============================================
// SCHEMA & MODEL
// ============================================

// Define Schema
const studentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Name is required"],
    minlength: 3
  },
  email: {
    type: String,
    required: [true, "Email is required"],
    unique: true,
    match: [/@/, "Invalid email"]
  },
  grade: {
    type: String,
    enum: ["A", "B", "C", "D", "F"],
    default: "C"
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create Model from Schema
const Student = mongoose.model("Student", studentSchema);

// ============================================
// ROUTES - CRUD OPERATIONS
// ============================================

// CREATE - Add new student
app.post("/api/students", async (req, res) => {
  try {
    const student = new Student(req.body);
    await student.save();
    
    console.log("✓ Student created:", student);
    res.status(201).json({
      success: true,
      message: "Student created",
      data: student
    });
  } catch (error) {
    console.log("❌ Error:", error.message);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// READ - Get all students
app.get("/api/students", async (req, res) => {
  try {
    const students = await Student.find();
    
    console.log(`✓ Retrieved ${students.length} students`);
    res.status(200).json({
      success: true,
      count: students.length,
      data: students
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// READ - Get single student
app.get("/api/students/:id", async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }
    
    console.log("✓ Student found:", student);
    res.status(200).json({
      success: true,
      data: student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// UPDATE - Update student
app.put("/api/students/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }
    
    console.log("✓ Student updated:", student);
    res.status(200).json({
      success: true,
      message: "Student updated",
      data: student
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// DELETE - Delete student
app.delete("/api/students/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found"
      });
    }
    
    console.log("✓ Student deleted:", student);
    res.status(200).json({
      success: true,
      message: "Student deleted",
      data: student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// ============================================
// HOME
// ============================================

app.get("/", (req, res) => {
  res.send(`
    <h1>MongoDB + Mongoose API</h1>
    <h2>Endpoints:</h2>
    <ul>
      <li>POST /api/students - Create</li>
      <li>GET /api/students - Get all</li>
      <li>GET /api/students/:id - Get one</li>
      <li>PUT /api/students/:id - Update</li>
      <li>DELETE /api/students/:id - Delete</li>
    </ul>
  `);
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});

module.exports = app;
