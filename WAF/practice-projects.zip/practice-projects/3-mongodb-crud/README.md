# MongoDB & Mongoose Practice

## Week 5-8 Projects

### 1-mongoose-crud.js
Complete MongoDB CRUD with Mongoose:
- **Schema Definition** with validation
- **Model Creation**
- **CRUD Operations** (Create, Read, Update, Delete)
- **Error Handling**

**Setup:**
```bash
npm install express mongoose
```

**MongoDB Connection String (Local):**
```
mongodb://localhost:27017/student-db
```

**MongoDB Atlas Connection String (Cloud):**
```
mongodb+srv://username:password@cluster.mongodb.net/dbname
```

### 2-validation.js
Schema Validation Examples:
- Built-in validators (required, minlength, maxlength, enum, match)
- Custom validation
- Async validation
- Pre/post hooks

## 🚀 Getting Started

### Install MongoDB Locally (Windows)
1. Download from mongodb.com
2. Install with default settings
3. MongoDB runs on localhost:27017

### OR Use MongoDB Atlas (Cloud)
1. Create account at mongodb.com
2. Create free cluster
3. Get connection string
4. Replace in code

### Start MongoDB
```bash
# Windows
mongod

# Mac/Linux
brew services start mongodb-community
```

### Test Data
```bash
# Open mongo shell
mongosh

# Create database
use student-db

# Insert test data
db.students.insertOne({
  name: "Alice",
  email: "alice@example.com",
  grade: "A"
})
```

## 📖 Key Concepts

**Schema** - Defines structure of documents

**Model** - Interface to database collections

**Validation** - Ensures data quality

**Hooks** - Pre/post actions (save, update, delete)

**Mongoose Methods:**
- `find()` - Get multiple documents
- `findById()` - Get one by ID
- `create()` - Create new
- `updateOne()` / `findByIdAndUpdate()` - Update
- `deleteOne()` / `findByIdAndDelete()` - Delete

## 🧪 Test API

```bash
# Create student
POST http://localhost:3004/api/students
{
  "name": "David",
  "email": "david@example.com",
  "grade": "A"
}

# Get all
GET http://localhost:3004/api/students

# Get one
GET http://localhost:3004/api/students/ID

# Update
PUT http://localhost:3004/api/students/ID
{
  "grade": "B"
}

# Delete
DELETE http://localhost:3004/api/students/ID
```

## Next: Week 9 - MVC Architecture

Structure your app with:
- **Models** - Database schemas
- **Views** - Templates/UI
- **Controllers** - Business logic
