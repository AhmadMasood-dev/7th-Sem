# 🚀 WAF Full-Stack Course - Practice Projects

Complete, practical practice projects for the **Web Application Framework** course covering **NodeJS → ExpressJS → MongoDB → ReactJS**.

## 📚 Project Structure

```
practice-projects/
├── 1-nodejs-basics/          📦 Week 1-2
├── 2-expressjs-api/          🌐 Week 3-6
├── 3-mongodb-crud/           🗄️  Week 5-8
└── 4-reactjs-app/            ⚛️  Week 11-16
```

---

## 📦 1. NodeJS Basics (Week 1-2)

**Topics:** Async/Await, Promises, File System, Modules, Web Servers

### Files:
- `1-async-await-tutorial.js` - Callbacks vs Promises vs Async/Await
- `2-file-system-operations.js` - CRUD with file system
- `3-modules-export.js` - Create and import custom modules
- `4-web-server.js` - Build a simple HTTP server with routing

### Key Concepts:
- ✓ Async/Await makes code look synchronous
- ✓ File system operations (read, write, append, delete)
- ✓ Create reusable modules
- ✓ Routing with native HTTP module

### Run:
```bash
node 1-async-await-tutorial.js
node 2-file-system-operations.js
node 3-modules-export.js
node 4-web-server.js
```

---

## 🌐 2. ExpressJS API (Week 3-6)

**Topics:** Routing, REST APIs, Middleware, Templating Engines, Forms

### Files:
- `1-rest-api.js` - Complete CRUD REST API
- `2-middleware.js` - Custom middleware, authentication, validation
- `3-templating-forms.js` - PUG templating with form handling

### Key Concepts:
- ✓ REST API design with GET/POST/PUT/DELETE
- ✓ HTTP status codes (200, 201, 400, 404, etc.)
- ✓ Middleware pipeline
- ✓ Authentication with tokens
- ✓ PUG templating engine
- ✓ Form validation

### Run:
```bash
npm install express
node 1-rest-api.js
node 2-middleware.js
node 3-templating-forms.js
```

### Test with Postman:
```
POST http://localhost:3001/api/students
Header: Content-Type: application/json
Body: { "name": "David", "grade": "A" }
```

---

## 🗄️ 3. MongoDB & Mongoose (Week 5-8)

**Topics:** Schema Design, Validation, CRUD, Mongoose, MongoDB Atlas

### Files:
- `1-mongoose-crud.js` - Complete CRUD with Mongoose
- `2-validation.js` - Schema validation examples

### Key Concepts:
- ✓ Schema definition and validation
- ✓ Built-in validators (required, minlength, match, enum)
- ✓ Mongoose methods (find, findById, updateOne, deleteOne)
- ✓ Error handling
- ✓ MongoDB local and cloud (Atlas)

### Setup:
```bash
npm install mongoose
```

### Connect to MongoDB:
```js
// Local
mongodb://localhost:27017/database-name

// Cloud (MongoDB Atlas)
mongodb+srv://username:password@cluster.mongodb.net/dbname
```

### Run:
```bash
node 1-mongoose-crud.js
```

---

## ⚛️ 4. React.js (Week 11-16)

**Topics:** Components, Hooks, State, Events, API Calls, Context API

### Files:
- `1-components-props.jsx` - Components & Props
- `2-state-events.jsx` - State management & event handling
- `3-component-communication.jsx` - Parent-child communication
- `4-hooks-useEffect-useContext-useRef.jsx` - Advanced hooks

### Key Concepts:
- ✓ **Components** - Reusable UI blocks
- ✓ **Props** - Pass data parent → child
- ✓ **State (useState)** - Component state management
- ✓ **Events** - onClick, onChange, onSubmit
- ✓ **useEffect** - Side effects and API calls
- ✓ **useContext** - Global state
- ✓ **useRef** - DOM access
- ✓ **Conditional Rendering** - Show/hide elements
- ✓ **Lists** - Render arrays with .map()

### Setup:
```bash
npx create-react-app my-app
cd my-app
npm start
```

### Copy Files:
Copy the `.jsx` files into `src/` folder of your React app.

### Run Example App:
```bash
# Create App.jsx
# Import and render: <App />
npm start
```

---

## 🎯 Learning Path

### Week 1-2: Master Node.js Fundamentals
1. Understand async/await (most important!)
2. Practice file operations
3. Create reusable modules
4. Build simple HTTP server

### Week 3-6: Build APIs with Express
1. Create REST APIs (CRUD)
2. Learn middleware pipeline
3. Add authentication
4. Handle forms with templating

### Week 5-8: Database with MongoDB
1. Design schemas
2. Add validation
3. Perform CRUD operations
4. Connect to cloud (Atlas)

### Week 11-16: Frontend with React
1. Build components
2. Manage state
3. Handle events
4. Fetch from API
5. Use advanced hooks

---

## 🔗 Full-Stack Integration Project

After learning all sections, build a **Complete Full-Stack App**:

### Backend (Node + Express + MongoDB)
```
server/
├── routes/
│   ├── users.js
│   └── posts.js
├── models/
│   ├── User.js
│   └── Post.js
├── controllers/
│   ├── userController.js
│   └── postController.js
└── server.js
```

### Frontend (React)
```
client/
├── components/
│   ├── Navbar.jsx
│   ├── UserCard.jsx
│   └── PostList.jsx
├── pages/
│   ├── Home.jsx
│   └── Profile.jsx
├── hooks/
│   └── useApi.js
└── App.jsx
```

### Example Flow:
1. React frontend fetches data from Express API
2. Express API queries MongoDB
3. Display data in React components

```jsx
// React component
useEffect(() => {
  fetch('http://localhost:3001/api/users')
    .then(res => res.json())
    .then(data => setUsers(data));
}, []);
```

---

## 📋 Common Commands

```bash
# NPM
npm init -y                 # Create package.json
npm install package-name    # Install package
npm install -D package      # Install as dev dependency

# Node
node filename.js           # Run file

# MongoDB
mongod                     # Start MongoDB server
mongosh                    # Open MongoDB shell

# React
npx create-react-app app   # Create new app
npm start                  # Start dev server
npm run build              # Build for production

# Git
git init                   # Initialize repo
git add .                  # Stage files
git commit -m "message"    # Commit
git push                   # Push to GitHub
```

---

## 🆘 Common Issues & Solutions

### MongoDB Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:27017
```
**Solution:** Make sure MongoDB is running
```bash
mongod  # Start MongoDB server
```

### Port Already in Use
```
Error: listen EADDRINUSE: address already in use :::3000
```
**Solution:** Change port or kill process using that port
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID pid_number /F

# Mac/Linux
lsof -i :3000
kill -9 process_id
```

### Module Not Found
```
Error: Cannot find module 'express'
```
**Solution:** Install dependencies
```bash
npm install
```

### CORS Error in React
```
Access to XMLHttpRequest blocked by CORS policy
```
**Solution:** Install cors middleware
```bash
npm install cors

// server.js
const cors = require('cors');
app.use(cors());
```

---

## 📖 External Resources

### Documentation
- [Node.js Docs](https://nodejs.org/docs/)
- [Express Docs](https://expressjs.com/)
- [MongoDB Docs](https://docs.mongodb.com/)
- [React Docs](https://react.dev)
- [Mongoose Docs](https://mongoosejs.com/)

### Tutorials
- [MDN - NodeJS](https://developer.mozilla.org/en-US/docs/Learn/Server-side/Express_Nodejs)
- [MDN - React](https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/Client-side_JavaScript_frameworks/React_getting_started)

### Online Playgrounds
- [Replit](https://replit.com) - Run code online
- [JSFiddle](https://jsfiddle.net) - React/JS playground
- [MongoDB Compass](https://www.mongodb.com/products/tools/compass) - GUI for MongoDB

---

## ✅ Checklist

### After NodeJS
- [ ] Understand async/await
- [ ] Create file operations
- [ ] Export modules
- [ ] Build HTTP server
- [ ] Understand routing

### After ExpressJS
- [ ] Create REST API
- [ ] Handle all HTTP methods
- [ ] Use middleware
- [ ] Validate data
- [ ] Render HTML templates

### After MongoDB
- [ ] Design schema
- [ ] Add validation
- [ ] CRUD operations
- [ ] Connect to cloud
- [ ] Handle errors

### After React
- [ ] Create components
- [ ] Manage state
- [ ] Handle events
- [ ] Fetch from API
- [ ] Use multiple hooks
- [ ] Understand Context API

---

## 🎓 Final Project Suggestions

1. **Todo App** - Simple CRUD with React + Express + MongoDB
2. **Blog Platform** - Create, read, update, delete posts
3. **Student Management** - Manage students, grades, attendance
4. **E-commerce** - Products, cart, checkout
5. **Chat Application** - Real-time messaging
6. **Social Media** - Posts, comments, likes, followers

---

## 💬 Tips for Success

✅ **Practice consistently** - 30 mins daily is better than 3 hours once
✅ **Type code yourself** - Don't copy-paste
✅ **Break projects into steps** - Don't build everything at once
✅ **Test as you go** - Use Postman, browser dev tools
✅ **Read error messages** - They tell you what's wrong
✅ **Google error messages** - Most errors are common
✅ **Join communities** - Stack Overflow, Reddit, Discord
✅ **Build projects** - Theory alone won't make you proficient

---

## 📞 Support

If you encounter issues:
1. Read the error message carefully
2. Check the relevant README.md in each project
3. Search the internet for the error
4. Ask in forums/communities
5. Compare with working code

---

**Happy Coding! 🚀**

Last updated: January 2026
