# Express.js API Practice

## Week 3-6 Projects

### 1-rest-api.js
Complete CRUD REST API for students:
- **GET** /api/students - Get all
- **GET** /api/students/:id - Get one
- **POST** /api/students - Create
- **PUT** /api/students/:id - Update
- **DELETE** /api/students/:id - Delete

**Test with Postman:**
```json
POST http://localhost:3001/api/students
Body: {
  "name": "David",
  "grade": "A"
}
```

### 2-middleware.js
Learn middleware concepts:
- Logging middleware
- Authentication middleware
- Validation middleware

**Test with Postman:**
Add header: `Authorization: Bearer secret-token-123`

### 3-templating-forms.js
PUG templating with forms:
- Render HTML with data
- Handle form submissions
- Validate inputs

**Setup:**
```bash
npm install express pug
npm install -g pug
```

**Create views/index.pug:**
```pug
h1 Users
ul
  each user in users
    li= user.name + " - " + user.email
a(href="/add-user") Add User
```

**Create views/form.pug:**
```pug
h1= title
form(method="POST" action="/add-user")
  input(type="text" name="name" placeholder="Name" required)
  input(type="email" name="email" placeholder="Email" required)
  button(type="submit") Add User
```

## 🚀 Run

```bash
# REST API
node 1-rest-api.js

# Middleware demo
node 2-middleware.js

# Forms with PUG
node 3-templating-forms.js
```

## 📖 Key Concepts

**CRUD** - Create, Read, Update, Delete operations

**REST** - Representational State Transfer API design

**Middleware** - Functions that process requests before routes

**PUG** - Templating language for HTML generation

**Status Codes:**
- 200 OK
- 201 Created
- 400 Bad Request
- 401 Unauthorized
- 404 Not Found
- 500 Server Error
