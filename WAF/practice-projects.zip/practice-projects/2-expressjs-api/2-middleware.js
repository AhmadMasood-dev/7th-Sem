// ============================================
// WEEK 5: Custom Middleware
// ============================================

const express = require("express");
const app = express();
const PORT = 3002;

console.log("=== EXPRESS MIDDLEWARE ===\n");

// ============================================
// 1. BUILT-IN MIDDLEWARE
// ============================================

// Parse JSON data
app.use(express.json());

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use(express.static("public"));

// ============================================
// 2. CUSTOM MIDDLEWARE (Logging)
// ============================================

app.use((req, res, next) => {
  const timestamp = new Date().toLocaleString();
  console.log(`[${timestamp}] ${req.method} ${req.url}`);
  next(); // Pass to next middleware/route
});

// ============================================
// 3. AUTHENTICATION MIDDLEWARE
// ============================================

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({
      success: false,
      message: "No token provided"
    });
  }

  if (token === "Bearer secret-token-123") {
    console.log("✓ User authenticated");
    next();
  } else {
    res.status(403).json({
      success: false,
      message: "Invalid token"
    });
  }
};

// ============================================
// 4. VALIDATION MIDDLEWARE
// ============================================

const validateUser = (req, res, next) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({
      success: false,
      message: "Name and email are required"
    });
  }

  if (!email.includes("@")) {
    return res.status(400).json({
      success: false,
      message: "Invalid email format"
    });
  }

  console.log("✓ User data validated");
  next();
};

// ============================================
// ROUTES
// ============================================

app.get("/", (req, res) => {
  res.send(`
    <h1>Middleware Demo</h1>
    <h2>Protected Routes (need token):</h2>
    <ul>
      <li>GET /api/protected - Protected route</li>
      <li>POST /api/users - Create user (with validation)</li>
    </ul>
    <p>Header: Authorization: Bearer secret-token-123</p>
  `);
});

// Public route
app.get("/api/public", (req, res) => {
  res.json({
    success: true,
    message: "This is a public route"
  });
});

// Protected route
app.get("/api/protected", authMiddleware, (req, res) => {
  res.json({
    success: true,
    message: "You accessed a protected route!"
  });
});

// Route with validation
app.post("/api/users", authMiddleware, validateUser, (req, res) => {
  console.log("✓ User created:", req.body);
  res.status(201).json({
    success: true,
    message: "User created",
    data: req.body
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log("\nTest with Postman:");
  console.log("  Header: Authorization: Bearer secret-token-123");
});
