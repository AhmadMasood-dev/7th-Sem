// ============================================
// WEEK 6: Templating Engine (PUG) & Forms
// ============================================

const express = require("express");
const path = require("path");
const app = express();
const PORT = 3003;

// Set view engine to PUG
app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// In-memory data
let users = [
  { id: 1, name: "Alice", email: "alice@example.com" },
  { id: 2, name: "Bob", email: "bob@example.com" }
];

console.log("=== PUG TEMPLATING ENGINE & FORMS ===\n");

// ============================================
// ROUTES
// ============================================

// Home page
app.get("/", (req, res) => {
  res.render("index", { users });
});

// Form page
app.get("/add-user", (req, res) => {
  res.render("form", { title: "Add New User" });
});

// Handle form submission
app.post("/add-user", (req, res) => {
  const { name, email } = req.body;

  // Validate
  if (!name || !email) {
    return res.render("form", {
      title: "Add New User",
      error: "Name and email are required!"
    });
  }

  // Create new user
  const newUser = {
    id: users.length ? Math.max(...users.map(u => u.id)) + 1 : 1,
    name,
    email
  };

  users.push(newUser);
  console.log("✓ User added:", newUser);

  // Redirect to home
  res.redirect("/");
});

// Delete user
app.get("/delete/:id", (req, res) => {
  const userId = parseInt(req.params.id);
  users = users.filter(u => u.id !== userId);
  console.log(`✓ User ${userId} deleted`);
  res.redirect("/");
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log("Visit: http://localhost:3003\n");
  console.log("⚠️  First, install PUG: npm install pug");
  console.log("⚠️  Create views folder with index.pug and form.pug files");
});
