// ============================================
// WEEK 3-4: Express.js Routing & REST APIs
// ============================================

const express = require("express");
const app = express();
const PORT = 3001;

// Middleware to parse JSON
app.use(express.json());

// In-memory database (for demo)
let students = [
  { id: 1, name: "Alice", grade: "A" },
  { id: 2, name: "Bob", grade: "B" },
  { id: 3, name: "Charlie", grade: "A" }
];

console.log("=== EXPRESSJS REST API ===\n");

// ============================================
// GET ROUTES
// ============================================

// GET all students
app.get("/api/students", (req, res) => {
  console.log("✓ GET /api/students");
  res.status(200).json({
    success: true,
    data: students
  });
});

// GET a specific student by ID
app.get("/api/students/:id", (req, res) => {
  const studentId = parseInt(req.params.id);
  const student = students.find(s => s.id === studentId);

  if (!student) {
    return res.status(404).json({
      success: false,
      message: "Student not found"
    });
  }

  console.log(`✓ GET /api/students/${studentId}`);
  res.status(200).json({
    success: true,
    data: student
  });
});

// ============================================
// POST ROUTE (Create)
// ============================================

app.post("/api/students", (req, res) => {
  const { name, grade } = req.body;

  // Validation
  if (!name || !grade) {
    return res.status(400).json({
      success: false,
      message: "Name and grade are required"
    });
  }

  const newStudent = {
    id: students.length ? Math.max(...students.map(s => s.id)) + 1 : 1,
    name,
    grade
  };

  students.push(newStudent);

  console.log(`✓ POST /api/students - Created:`, newStudent);
  res.status(201).json({
    success: true,
    message: "Student created",
    data: newStudent
  });
});

// ============================================
// PUT ROUTE (Update)
// ============================================

app.put("/api/students/:id", (req, res) => {
  const studentId = parseInt(req.params.id);
  const student = students.find(s => s.id === studentId);

  if (!student) {
    return res.status(404).json({
      success: false,
      message: "Student not found"
    });
  }

  // Update fields
  if (req.body.name) student.name = req.body.name;
  if (req.body.grade) student.grade = req.body.grade;

  console.log(`✓ PUT /api/students/${studentId} - Updated:`, student);
  res.status(200).json({
    success: true,
    message: "Student updated",
    data: student
  });
});

// ============================================
// DELETE ROUTE
// ============================================

app.delete("/api/students/:id", (req, res) => {
  const studentId = parseInt(req.params.id);
  const index = students.findIndex(s => s.id === studentId);

  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: "Student not found"
    });
  }

  const deletedStudent = students.splice(index, 1);

  console.log(`✓ DELETE /api/students/${studentId}`);
  res.status(200).json({
    success: true,
    message: "Student deleted",
    data: deletedStudent
  });
});

// ============================================
// HOME ROUTE
// ============================================

app.get("/", (req, res) => {
  res.send(`
    <h1>Express REST API</h1>
    <h2>API Endpoints:</h2>
    <ul>
      <li>GET /api/students - Get all students</li>
      <li>GET /api/students/:id - Get student by ID</li>
      <li>POST /api/students - Create new student</li>
      <li>PUT /api/students/:id - Update student</li>
      <li>DELETE /api/students/:id - Delete student</li>
    </ul>
    <p>Use Postman to test these endpoints!</p>
  `);
});

// 404 route
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found"
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log("\nAPI Endpoints:");
  console.log("  GET    http://localhost:3001/api/students");
  console.log("  GET    http://localhost:3001/api/students/1");
  console.log("  POST   http://localhost:3001/api/students");
  console.log("  PUT    http://localhost:3001/api/students/1");
  console.log("  DELETE http://localhost:3001/api/students/1");
  console.log("\n📝 Test with Postman!");
});
