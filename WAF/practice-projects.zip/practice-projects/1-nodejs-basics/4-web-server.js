// ============================================
// WEEK 2: Creating a Simple Web Server
// ============================================

const http = require("http");

// Define the port
const PORT = 3000;

// Create a server
const server = http.createServer((req, res) => {
  // Set response header
  res.setHeader("Content-Type", "text/html; charset=utf-8");

  console.log("Request URL:", req.url);
  console.log("Request Method:", req.method);

  // ROUTING - Handle different URLs
  if (req.url === "/" && req.method === "GET") {
    res.statusCode = 200;
    res.end(`
      <h1>Welcome to Node.js Web Server</h1>
      <p>This is a simple web server built with Node.js!</p>
      <a href="/about">Go to About</a>
    `);
  } else if (req.url === "/about" && req.method === "GET") {
    res.statusCode = 200;
    res.end(`
      <h1>About Page</h1>
      <p>This is the about page</p>
      <a href="/">Go Home</a>
    `);
  } else if (req.url === "/api/users" && req.method === "GET") {
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify([
      { id: 1, name: "Alice" },
      { id: 2, name: "Bob" }
    ]));
  } else {
    res.statusCode = 404;
    res.end("<h1>404 - Page Not Found</h1>");
  }
});

// Start the server
server.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
  console.log("Press Ctrl+C to stop the server\n");
  console.log("Try these URLs:");
  console.log("  http://localhost:3000/");
  console.log("  http://localhost:3000/about");
  console.log("  http://localhost:3000/api/users");
});
