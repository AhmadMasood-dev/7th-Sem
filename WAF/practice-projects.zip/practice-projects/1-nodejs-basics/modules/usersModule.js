// ============================================
// Custom Users Module
// ============================================

let users = [
  { id: 1, name: "Alice", email: "alice@example.com" },
  { id: 2, name: "Bob", email: "bob@example.com" }
];

function getAllUsers() {
  return users;
}

function getUserById(id) {
  return users.find(user => user.id === id);
}

function addUser(user) {
  users.push(user);
  return user;
}

function deleteUser(id) {
  users = users.filter(user => user.id !== id);
  return "User deleted";
}

// EXPORT the functions
module.exports = {
  getAllUsers,
  getUserById,
  addUser,
  deleteUser
};
