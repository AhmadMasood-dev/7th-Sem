// ============================================
// WEEK 2: Creating and Exporting Modules
// ============================================

// This is the MAIN FILE that uses the modules

// Import our custom modules
const math = require("./modules/mathModule");
const users = require("./modules/usersModule");

console.log("=== USING CUSTOM MODULES ===\n");

// 1. Use math module
console.log("1️⃣  Math Module:");
console.log("Add 10 + 5 =", math.add(10, 5));
console.log("Subtract 10 - 5 =", math.subtract(10, 5));
console.log("Multiply 10 * 5 =", math.multiply(10, 5));
console.log("Divide 10 / 5 =", math.divide(10, 5));

// 2. Use users module
console.log("\n2️⃣  Users Module:");
console.log("All users:", users.getAllUsers());
console.log("User with ID 1:", users.getUserById(1));

users.addUser({ id: 3, name: "Charlie", email: "charlie@example.com" });
console.log("Users after adding:", users.getAllUsers());
