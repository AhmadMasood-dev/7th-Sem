// ============================================
// WEEK 1-2: File System Module
// ============================================

const fs = require("fs");
const path = require("path");

console.log("=== FILE SYSTEM OPERATIONS ===\n");

// 1. CREATE A FILE (Write to file)
console.log("1️⃣  Creating a file...");
const filePath = path.join(__dirname, "user-data.txt");
const content = "Name: John Doe\nAge: 25\nCity: Karachi";

fs.writeFileSync(filePath, content);
console.log("✓ File created at:", filePath);

// 2. READ A FILE
console.log("\n2️⃣  Reading the file...");
const fileContent = fs.readFileSync(filePath, "utf8");
console.log("File content:\n", fileContent);

// 3. APPEND TO FILE
console.log("\n3️⃣  Appending to file...");
fs.appendFileSync(filePath, "\nEmail: john@example.com");
console.log("✓ Data appended");

// 4. UPDATE/OVERWRITE FILE
console.log("\n4️⃣  Updating file...");
const updatedContent = "Name: Jane Doe\nAge: 30\nCity: Islamabad";
fs.writeFileSync(filePath, updatedContent);
console.log("✓ File updated");

// 5. DELETE FILE
console.log("\n5️⃣  Deleting file...");
fs.unlinkSync(filePath);
console.log("✓ File deleted");

// ============================================
// ASYNCHRONOUS FILE OPERATIONS
// ============================================

console.log("\n=== ASYNC FILE OPERATIONS ===\n");

const asyncFilePath = path.join(__dirname, "async-data.txt");

// Async Write
async function asyncOperations() {
  try {
    // Write
    console.log("Writing file asynchronously...");
    await fs.promises.writeFile(asyncFilePath, "This is async data\n");

    // Read
    console.log("Reading file asynchronously...");
    let data = await fs.promises.readFile(asyncFilePath, "utf8");
    console.log("Content:", data);

    // Append
    console.log("Appending to file...");
    await fs.promises.appendFile(asyncFilePath, "More async data\n");

    // Read again
    data = await fs.promises.readFile(asyncFilePath, "utf8");
    console.log("Updated content:\n", data);

    // Delete
    console.log("Deleting file...");
    await fs.promises.unlink(asyncFilePath);
    console.log("✓ File deleted successfully\n");
  } catch (error) {
    console.error("Error:", error.message);
  }
}

asyncOperations();
