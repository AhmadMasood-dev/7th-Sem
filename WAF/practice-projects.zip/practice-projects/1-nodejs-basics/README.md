# 📚 NodeJS Basics Practice Projects

These projects cover **Week 1-2** of the WAF course: Async/Await, Promises, File System, Modules, and Web Servers.

## 📁 Files

1. **1-async-await-tutorial.js** - Learn the evolution from Callbacks → Promises → Async/Await
2. **2-file-system-operations.js** - CRUD operations with file system
3. **3-modules-export.js** - Import and use custom modules
4. **modules/mathModule.js** - Custom math functions module
5. **modules/usersModule.js** - Custom users management module
6. **4-web-server.js** - Create a simple web server with routing

## 🚀 How to Run

### Run individual files:
```bash
node 1-async-await-tutorial.js
node 2-file-system-operations.js
node 3-modules-export.js
```

### Run the web server:
```bash
node 4-web-server.js
```

Then open your browser and visit:
- http://localhost:3000/
- http://localhost:3000/about
- http://localhost:3000/api/users

## 📖 Key Concepts Explained

### Async/Await
- Makes asynchronous code look synchronous
- Easier to read than promises and callbacks
- Use `try/catch` for error handling

### File System Module
- `writeFileSync()` - Write synchronously
- `readFileSync()` - Read synchronously
- `fs.promises` - Use for async operations

### Modules
- `module.exports` - Export functions/objects
- `require()` - Import modules
- Can be files or folders with index.js

### Web Server
- `http.createServer()` - Create server
- `req.url` and `req.method` - Get request info
- `res.statusCode`, `res.setHeader()`, `res.end()` - Send response

## 💡 Next Steps
After mastering these, move to **ExpressJS** for easier routing and middleware!
