// ============================================
// WEEK 1: Async/Await, Promises, Callbacks
// ============================================

console.log("=== CALLBACKS (Old Way) ===\n");

// ❌ CALLBACK HELL - Hard to read and maintain
function fetchUserData(userId, callback) {
  setTimeout(() => {
    console.log(`✓ Fetched user ${userId}`);
    callback({ id: userId, name: "John" });
  }, 1000);
}

function fetchUserPosts(userId, callback) {
  setTimeout(() => {
    console.log(`✓ Fetched posts for user ${userId}`);
    callback([
      { id: 1, title: "Post 1" },
      { id: 2, title: "Post 2" }
    ]);
  }, 1000);
}

// Callback Hell Example
// fetchUserData(1, (user) => {
//   console.log("User:", user);
//   fetchUserPosts(user.id, (posts) => {
//     console.log("Posts:", posts);
//     // More nested callbacks... UGLY!
//   });
// });

console.log("\n=== PROMISES (Better Way) ===\n");

// ✓ PROMISES - Cleaner, easier to read
function fetchUserDataPromise(userId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log(`✓ Fetched user ${userId}`);
      resolve({ id: userId, name: "Jane" });
    }, 1000);
  });
}

function fetchUserPostsPromise(userId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log(`✓ Fetched posts for user ${userId}`);
      resolve([
        { id: 1, title: "Learning JS" },
        { id: 2, title: "Node.js Tips" }
      ]);
    }, 1000);
  });
}

// Promise Chain
// fetchUserDataPromise(1)
//   .then(user => {
//     console.log("User:", user);
//     return fetchUserPostsPromise(user.id);
//   })
//   .then(posts => {
//     console.log("Posts:", posts);
//   })
//   .catch(error => console.error("Error:", error));

console.log("\n=== ASYNC/AWAIT (Best Way) ===\n");

// ✓✓ ASYNC/AWAIT - Looks like synchronous code, super clean!
async function getUserWithPosts(userId) {
  try {
    const user = await fetchUserDataPromise(userId);
    console.log("User:", user);

    const posts = await fetchUserPostsPromise(user.id);
    console.log("Posts:", posts);

    return { user, posts };
  } catch (error) {
    console.error("Error:", error);
  }
}

// Run the async function
getUserWithPosts(1).then(result => {
  console.log("\n=== FINAL RESULT ===");
  console.log(result);
});
