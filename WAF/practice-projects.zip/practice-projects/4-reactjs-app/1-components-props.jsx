// ============================================
// WEEK 11: React Basics - Components & Props
// ============================================

import React from 'react';

// ============================================
// FUNCTIONAL COMPONENT
// ============================================

function Greeting({ name, age }) {
  return (
    <div>
      <h1>Hello, {name}!</h1>
      <p>Age: {age}</p>
    </div>
  );
}

// ============================================
// REUSABLE COMPONENTS
// ============================================

function Card({ title, description, onClick }) {
  return (
    <div style={{
      border: "2px solid #ccc",
      padding: "20px",
      borderRadius: "8px",
      margin: "10px 0",
      cursor: "pointer"
    }}
    onClick={onClick}>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  );
}

// ============================================
// MAIN APP
// ============================================

function App() {
  const users = [
    { name: "Alice", age: 25 },
    { name: "Bob", age: 30 },
    { name: "Charlie", age: 28 }
  ];

  const handleCardClick = (title) => {
    alert(`You clicked on: ${title}`);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>React Components & Props</h1>

      {/* Component with props */}
      <Greeting name="John" age={25} />

      {/* Reusable Card components */}
      <h2>Cards:</h2>
      {users.map((user, index) => (
        <Card
          key={index}
          title={user.name}
          description={`Age: ${user.age}`}
          onClick={() => handleCardClick(user.name)}
        />
      ))}
    </div>
  );
}

export default App;

/*
KEY CONCEPTS:

1. COMPONENTS
   - Reusable UI building blocks
   - Functional components (modern)
   - Class components (legacy)

2. PROPS
   - Pass data from parent to child
   - Read-only (cannot modify)
   - Function parameters for components

3. DESTRUCTURING
   - Extract props in function parameters
   - { name, age } instead of props.name

4. RENDERING LISTS
   - Use .map() to render arrays
   - Always add unique key prop
*/
