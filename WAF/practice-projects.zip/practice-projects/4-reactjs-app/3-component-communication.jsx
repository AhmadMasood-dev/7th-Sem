// ============================================
// WEEK 13-14: Component Communication
// ============================================

import React, { useState } from 'react';

// ============================================
// CHILD COMPONENT - Receives props
// ============================================

function StudentCard({ student, onDelete, onSelect }) {
  return (
    <div style={{
      border: "2px solid #2196F3",
      padding: "15px",
      borderRadius: "8px",
      margin: "10px 0",
      cursor: "pointer",
      backgroundColor: "#f0f4ff"
    }}
    onClick={() => onSelect(student)}>
      <h3>{student.name}</h3>
      <p>Email: {student.email}</p>
      <p>Grade: {student.grade}</p>
      <button
        onClick={(e) => {
          e.stopPropagation();
          onDelete(student.id);
        }}
        style={{ backgroundColor: "red", color: "white", padding: "8px 12px", border: "none", borderRadius: "4px", cursor: "pointer" }}
      >
        Delete
      </button>
    </div>
  );
}

// ============================================
// PARENT COMPONENT - Manages state
// ============================================

function StudentList() {
  const [students, setStudents] = useState([
    { id: 1, name: "Alice", email: "alice@example.com", grade: "A" },
    { id: 2, name: "Bob", email: "bob@example.com", grade: "B" },
    { id: 3, name: "Charlie", email: "charlie@example.com", grade: "A" }
  ]);

  const [selectedStudent, setSelectedStudent] = useState(null);
  const [newStudent, setNewStudent] = useState({ name: "", email: "", grade: "A" });

  // Method: Delete student
  const handleDelete = (id) => {
    setStudents(students.filter(s => s.id !== id));
    setSelectedStudent(null);
  };

  // Method: Select student (pass to child)
  const handleSelect = (student) => {
    setSelectedStudent(student);
  };

  // Method: Add student
  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.email) {
      alert("Fill all fields!");
      return;
    }

    const student = {
      id: Date.now(),
      ...newStudent
    };

    setStudents([...students, student]);
    setNewStudent({ name: "", email: "", grade: "A" });
  };

  return (
    <div style={{ maxWidth: "800px", margin: "auto", padding: "20px", fontFamily: "Arial" }}>
      <h1>Student Management App</h1>

      {/* ADD STUDENT FORM */}
      <div style={{ backgroundColor: "#f9f9f9", padding: "20px", borderRadius: "8px", marginBottom: "20px" }}>
        <h2>Add Student</h2>
        <input
          type="text"
          placeholder="Name"
          value={newStudent.name}
          onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
          style={{ display: "block", padding: "10px", margin: "10px 0", width: "100%", boxSizing: "border-box" }}
        />
        <input
          type="email"
          placeholder="Email"
          value={newStudent.email}
          onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
          style={{ display: "block", padding: "10px", margin: "10px 0", width: "100%", boxSizing: "border-box" }}
        />
        <select
          value={newStudent.grade}
          onChange={(e) => setNewStudent({ ...newStudent, grade: e.target.value })}
          style={{ display: "block", padding: "10px", margin: "10px 0", width: "100%", boxSizing: "border-box" }}
        >
          <option>A</option>
          <option>B</option>
          <option>C</option>
          <option>D</option>
        </select>
        <button
          onClick={handleAddStudent}
          style={{ padding: "10px 20px", backgroundColor: "#4CAF50", color: "white", border: "none", borderRadius: "4px", cursor: "pointer", width: "100%" }}
        >
          Add Student
        </button>
      </div>

      {/* STUDENT LIST */}
      <div>
        <h2>Students ({students.length})</h2>
        {students.length === 0 ? (
          <p>No students yet. Add one!</p>
        ) : (
          students.map(student => (
            <StudentCard
              key={student.id}
              student={student}
              onDelete={handleDelete}
              onSelect={handleSelect}
            />
          ))
        )}
      </div>

      {/* SELECTED STUDENT DETAILS */}
      {selectedStudent && (
        <div style={{ backgroundColor: "#fff3cd", padding: "20px", borderRadius: "8px", marginTop: "20px" }}>
          <h2>Selected Student Details</h2>
          <p><strong>Name:</strong> {selectedStudent.name}</p>
          <p><strong>Email:</strong> {selectedStudent.email}</p>
          <p><strong>Grade:</strong> {selectedStudent.grade}</p>
          <button onClick={() => setSelectedStudent(null)}>Clear Selection</button>
        </div>
      )}
    </div>
  );
}

export default StudentList;

/*
KEY CONCEPTS:

1. PARENT → CHILD (Props)
   - Parent passes data down as props
   - Child receives and displays data
   - Props are read-only (immutable)

2. CHILD → PARENT (Callbacks)
   - Parent passes callback function as prop
   - Child calls the callback to send data up
   - Example: onClick={() => onDelete(id)}

3. EVENT PROPAGATION
   - e.stopPropagation() - Stop event from bubbling
   - Useful when child and parent both handle events

4. ARRAY/OBJECT MANIPULATION
   - Add: [...array, newItem]
   - Remove: array.filter(item => item.id !== id)
   - Update: array.map(item => item.id === id ? {...item, prop: value} : item)
   - Update object: {...object, prop: value}

5. CONDITIONAL RENDERING
   - {condition && <JSX />}
   - {array.length === 0 ? <Empty /> : <List />}

6. DYNAMIC LISTS
   - Always use .map() for lists
   - key prop must be unique and stable
   - index as key is NOT recommended
*/
