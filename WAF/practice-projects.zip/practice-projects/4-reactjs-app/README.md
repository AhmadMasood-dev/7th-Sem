# React.js Practice Projects

## Week 11-16 Projects

All files use **React Hooks** (modern approach).

### 1-components-props.jsx
**Week 11: Components & Props**
- Functional components
- Passing props
- Props destructuring
- Rendering lists with .map()

**Key Concept:**
```jsx
function Greeting({ name, age }) {
  return <h1>Hello {name}, Age: {age}</h1>;
}

// Use: <Greeting name="Alice" age={25} />
```

### 2-state-events.jsx
**Week 12: State & Events**
- useState hook for state management
- Event handling (onClick, onChange, onSubmit)
- Form handling with controlled inputs
- State with arrays and objects
- Conditional rendering

**Key Concept:**
```jsx
const [count, setCount] = useState(0);
const handleClick = () => setCount(count + 1);
```

### 3-component-communication.jsx
**Week 13-14: Component Communication**
- Parent → Child (Props)
- Child → Parent (Callbacks)
- Managing shared state
- Building real app (Student Management)

**Key Concept:**
```jsx
// Parent
<Child data={data} onAction={handleAction} />

// Child
function Child({ data, onAction }) {
  return <button onClick={() => onAction(data.id)}>Click</button>;
}
```

### 4-hooks-useEffect-useContext-useRef.jsx
**Week 15-16: Advanced Hooks**
- **useEffect** - Side effects, API calls, cleanup
- **useContext** - Global state without prop drilling
- **useRef** - DOM access, persistent values
- Combining multiple hooks

**Key Concepts:**

**useEffect:**
```jsx
// Run once on mount
useEffect(() => { ... }, [])

// Run when dependency changes
useEffect(() => { ... }, [dependency])

// Cleanup function
useEffect(() => {
  return () => { ... }
}, [])
```

**useContext:**
```jsx
const MyContext = createContext();
function App() {
  return <MyContext.Provider value={data}><Child /></MyContext.Provider>;
}
function Child() {
  const data = useContext(MyContext);
}
```

**useRef:**
```jsx
const inputRef = useRef(null);
function handleClick() {
  inputRef.current.focus();
}
```

## 🚀 Setup

```bash
# Create React app
npx create-react-app my-app
cd my-app

# Start development server
npm start
```

## 📖 React Folder Structure

```
src/
├── components/
│   ├── Header.jsx
│   ├── Footer.jsx
│   └── Card.jsx
├── pages/
│   ├── Home.jsx
│   └── About.jsx
├── hooks/
│   └── useCustom.js
├── context/
│   └── ThemeContext.js
├── App.jsx
└── index.js
```

## 📚 Key Hooks Cheat Sheet

| Hook | Purpose | When to Use |
|------|---------|------------|
| `useState` | Manage component state | Form inputs, toggles, counters |
| `useEffect` | Side effects | API calls, timers, subscriptions |
| `useContext` | Global state | Theme, user data, settings |
| `useRef` | DOM access | Focus input, play video |
| `useReducer` | Complex state | App-wide state management |
| `useMemo` | Optimize performance | Expensive calculations |
| `useCallback` | Optimize callbacks | Prevent unnecessary re-renders |

## 🧪 Testing API Calls

Use `fetch()` or `axios`:

```jsx
useEffect(() => {
  fetch("https://api.example.com/data")
    .then(res => res.json())
    .then(data => setData(data))
    .catch(err => console.error(err));
}, []);
```

## 💡 Common Patterns

**Conditional Rendering:**
```jsx
{isLoading && <p>Loading...</p>}
{error && <p>Error: {error}</p>}
{data && <DataComponent data={data} />}
```

**Form Validation:**
```jsx
const handleSubmit = (e) => {
  e.preventDefault();
  if (!email.includes("@")) return alert("Invalid email");
  // Submit form
};
```

**State with Objects:**
```jsx
const [user, setUser] = useState({ name: "", age: 0 });
setUser({ ...user, name: "Alice" });
```

**State with Arrays:**
```jsx
setItems([...items, newItem]);
setItems(items.filter(item => item.id !== id));
setItems(items.map(item => item.id === id ? {...item, prop: value} : item));
```

## 🎓 Next: Full-Stack Integration

Connect React with:
1. **Backend API** - Fetch from ExpressJS
2. **Database** - MongoDB for persistence
3. **Authentication** - Login/register
4. **State Management** - Redux or Context API

## 📖 Resources

- [React Official Docs](https://react.dev)
- [Hooks API Reference](https://react.dev/reference/react)
- [React Router](https://reactrouter.com) - Page navigation
- [Redux](https://redux.js.org) - Global state management
