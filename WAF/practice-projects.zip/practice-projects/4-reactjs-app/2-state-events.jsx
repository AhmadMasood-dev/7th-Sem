// ============================================
// WEEK 12: State & Event Handling
// ============================================

import React, { useState } from 'react';

// ============================================
// STATE MANAGEMENT
// ============================================

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div style={{ padding: "20px", border: "1px solid #ccc" }}>
      <h2>Counter: {count}</h2>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={() => setCount(count - 1)}>Decrement</button>
      <button onClick={() => setCount(0)}>Reset</button>
    </div>
  );
}

// ============================================
// FORM HANDLING
// ============================================

function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent page reload

    if (!email || !password) {
      setMessage("❌ Email and password required!");
      return;
    }

    setMessage(`✓ Welcome ${email}!`);
    setEmail("");
    setPassword("");
  };

  return (
    <div style={{ padding: "20px", border: "1px solid #ccc", margin: "10px 0" }}>
      <h2>Login Form</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{ display: "block", padding: "10px", margin: "10px 0" }}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ display: "block", padding: "10px", margin: "10px 0" }}
        />
        <button type="submit">Login</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
}

// ============================================
// EVENT HANDLING - MULTIPLE EVENTS
// ============================================

function EventDemo() {
  const [bgColor, setBgColor] = useState("white");

  return (
    <div
      style={{
        padding: "20px",
        backgroundColor: bgColor,
        border: "1px solid #ccc",
        margin: "10px 0",
        transition: "0.3s"
      }}
      onMouseEnter={() => setBgColor("lightblue")}
      onMouseLeave={() => setBgColor("white")}
    >
      <h2>Hover over this box</h2>
      <p>Background changes on mouse enter/leave</p>
    </div>
  );
}

// ============================================
// STATE WITH ARRAYS & OBJECTS
// ============================================

function TodoApp() {
  const [todos, setTodos] = useState([
    { id: 1, text: "Learn React", completed: false }
  ]);
  const [input, setInput] = useState("");

  const addTodo = () => {
    if (!input.trim()) return;

    const newTodo = {
      id: Date.now(),
      text: input,
      completed: false
    };

    setTodos([...todos, newTodo]);
    setInput("");
  };

  const toggleTodo = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  return (
    <div style={{ padding: "20px", border: "1px solid #ccc", margin: "10px 0" }}>
      <h2>Todo App</h2>
      <div style={{ display: "flex", gap: "10px" }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && addTodo()}
          placeholder="Add a todo..."
          style={{ padding: "8px", flex: 1 }}
        />
        <button onClick={addTodo}>Add</button>
      </div>

      <ul style={{ marginTop: "20px" }}>
        {todos.map(todo => (
          <li key={todo.id} style={{
            textDecoration: todo.completed ? "line-through" : "none",
            padding: "10px",
            backgroundColor: todo.completed ? "#e8f5e9" : "#fff3e0",
            margin: "5px 0",
            borderRadius: "4px",
            display: "flex",
            justifyContent: "space-between"
          }}>
            <span
              onClick={() => toggleTodo(todo.id)}
              style={{ cursor: "pointer", flex: 1 }}
            >
              {todo.text}
            </span>
            <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ============================================
// MAIN APP
// ============================================

function App() {
  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>React State & Events</h1>

      <Counter />
      <LoginForm />
      <EventDemo />
      <TodoApp />
    </div>
  );
}

export default App;

/*
KEY CONCEPTS:

1. STATE (useState Hook)
   - const [value, setValue] = useState(initialValue)
   - Triggers re-render when changed
   - Each component has its own state

2. EVENT HANDLING
   - onClick, onChange, onSubmit, etc.
   - e.preventDefault() - prevent default behavior
   - Arrow functions to pass arguments

3. FORM HANDLING
   - Controlled components (state controls input)
   - onChange updates state
   - onSubmit handles form submission

4. STATE WITH ARRAYS/OBJECTS
   - Don't mutate directly
   - Use [...array, newItem] to add
   - Use array.map() to update
   - Use array.filter() to remove
   - Use { ...object, prop: value } to update objects

5. CONDITIONAL RENDERING
   - {condition && <Component />}
   - Use ternary operator for if-else
*/
