// ============================================
// WEEK 15-16: React Hooks (useEffect, useContext, useRef)
// ============================================

import React, { useState, useEffect, useContext, useRef, createContext } from 'react';

// ============================================
// 1. useEffect HOOK - Side Effects
// ============================================

function EffectDemo() {
  const [count, setCount] = useState(0);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  // Run once on mount
  useEffect(() => {
    console.log("✓ Component mounted");
    document.title = "React Hooks Demo";

    return () => {
      console.log("✓ Component unmounted (cleanup)");
    };
  }, []); // Empty dependency array

  // Run when count changes
  useEffect(() => {
    console.log(`Count changed to: ${count}`);
  }, [count]); // Dependency array with count

  // Fetch data from API
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Simulating API call
        const response = await fetch("https://jsonplaceholder.typicode.com/users/1");
        const json = await response.json();
        setData(json);
      } catch (error) {
        console.error("Fetch error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []); // Run once on mount

  return (
    <div style={{ padding: "20px", border: "1px solid #ccc", margin: "10px 0", borderRadius: "8px" }}>
      <h2>useEffect Hook</h2>
      <p>Count: <strong>{count}</strong></p>
      <button onClick={() => setCount(count + 1)}>Increment</button>

      {loading ? (
        <p>Loading...</p>
      ) : data ? (
        <div>
          <p><strong>User:</strong> {data.name}</p>
          <p><strong>Email:</strong> {data.email}</p>
        </div>
      ) : null}
    </div>
  );
}

// ============================================
// 2. useContext HOOK - Global State
// ============================================

// Create context
const ThemeContext = createContext();

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

function ThemedComponent() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  const bgColor = theme === "light" ? "white" : "#333";
  const textColor = theme === "light" ? "black" : "white";

  return (
    <div style={{
      backgroundColor: bgColor,
      color: textColor,
      padding: "20px",
      borderRadius: "8px",
      margin: "10px 0",
      border: `2px solid ${textColor}`
    }}>
      <h2>Current Theme: {theme}</h2>
      <button onClick={toggleTheme}>Toggle Theme</button>
    </div>
  );
}

// ============================================
// 3. useRef HOOK - DOM Reference
// ============================================

function RefDemo() {
  const inputRef = useRef(null);
  const countRef = useRef(0);

  const focusInput = () => {
    inputRef.current.focus();
  };

  const incrementRef = () => {
    countRef.current++;
    console.log(`Ref count (no re-render): ${countRef.current}`);
    alert(`Ref count: ${countRef.current}`);
  };

  return (
    <div style={{ padding: "20px", border: "1px solid #ccc", margin: "10px 0", borderRadius: "8px" }}>
      <h2>useRef Hook</h2>

      {/* useRef for DOM access */}
      <input
        ref={inputRef}
        type="text"
        placeholder="Click button to focus"
        style={{ padding: "8px", marginRight: "10px" }}
      />
      <button onClick={focusInput}>Focus Input</button>

      {/* useRef for persistent value (no re-render) */}
      <div style={{ marginTop: "20px" }}>
        <p>Check console for ref count updates</p>
        <button onClick={incrementRef}>Increment Ref (no re-render)</button>
      </div>
    </div>
  );
}

// ============================================
// 4. ADVANCED: Combining All Hooks
// ============================================

function AdvancedApp() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const searchRef = useRef(null);
  const { theme } = useContext(ThemeContext);

  // Fetch users when component mounts
  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      try {
        const response = await fetch("https://jsonplaceholder.typicode.com/users");
        const data = await response.json();
        setUsers(data.slice(0, 5));
      } catch (error) {
        console.error("Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []); // Run once on mount

  const handleSearch = () => {
    const searchTerm = searchRef.current.value;
    console.log(`Searching for: ${searchTerm}`);
    alert(`Searching for: ${searchTerm}`);
  };

  const bgColor = theme === "light" ? "#f5f5f5" : "#222";
  const textColor = theme === "light" ? "black" : "white";

  return (
    <div style={{
      backgroundColor: bgColor,
      color: textColor,
      padding: "20px",
      borderRadius: "8px",
      margin: "10px 0"
    }}>
      <h2>Advanced Hooks Demo</h2>

      {/* Search with useRef */}
      <div style={{ marginBottom: "20px" }}>
        <input
          ref={searchRef}
          type="text"
          placeholder="Search users..."
          style={{ padding: "8px", marginRight: "10px" }}
        />
        <button onClick={handleSearch}>Search</button>
      </div>

      {/* Display users with useEffect */}
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <h3>Users:</h3>
          <ul>
            {users.map(user => (
              <li key={user.id}>{user.name} - {user.email}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

// ============================================
// MAIN APP
// ============================================

function App() {
  return (
    <ThemeProvider>
      <div style={{ fontFamily: "Arial", maxWidth: "900px", margin: "auto", padding: "20px" }}>
        <h1>React Hooks Deep Dive</h1>

        <EffectDemo />
        <ThemedComponent />
        <RefDemo />
        <AdvancedApp />
      </div>
    </ThemeProvider>
  );
}

export default App;

/*
KEY CONCEPTS:

1. useEffect HOOK
   - Side effects: API calls, subscriptions, timers
   - Syntax: useEffect(() => { ... }, [dependencies])
   - Empty array [] = run once on mount
   - [dep] = run when dep changes
   - Return function for cleanup
   - Example: Fetch data, timers, event listeners

2. useContext HOOK
   - Share state across components without prop drilling
   - createContext() - Create context
   - Provider - Provides context value
   - useContext() - Use context in component
   - Avoids passing props through many levels

3. useRef HOOK
   - Access DOM nodes directly
   - inputRef.current.focus()
   - Persistent value that doesn't cause re-render
   - .current property contains the value
   - Common uses: focus, text selection, media playback control

4. DEPENDENCY ARRAY
   - [] - Run once on mount, cleanup on unmount
   - [value] - Run when value changes, cleanup when unmount/value changes
   - No array - Run after every render
   - Add all external values used in effect

5. CLEANUP FUNCTIONS
   - Return function from useEffect
   - Runs before effect runs again or on unmount
   - Remove subscriptions, timers, event listeners

BEST PRACTICES:
- Put all useState at top of component
- Don't call hooks conditionally
- Use custom hooks to share logic
- useEffect for side effects, not for rendering
- Always include all dependencies in dependency array
*/
